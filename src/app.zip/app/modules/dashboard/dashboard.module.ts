import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserTableComponent } from './user-table/user-table.component';
import { UnlockUserAccountComponent } from './unlock-user-account/unlock-user-account.component';
import { ResendTokenComponent } from './resend-token/resend-token.component';
import { ResendThankyouComponent } from './resend-thankyou/resend-thankyou.component';
import { IdProofingComponent } from './id-proofing/id-proofing.component';
import { RestartIdProofingComponent } from './restart-id-proofing/restart-id-proofing.component';
import { ConfirmReactivateComponent } from './confirm-reactivate/confirm-reactivate.component';
import { ReactivateSuccessfulComponent } from './reactivate-successful/reactivate-successful.component';


@NgModule({
  declarations: [
    DashboardComponent,
    UserTableComponent,
    UnlockUserAccountComponent,
    ResendTokenComponent,
    ResendThankyouComponent,
    IdProofingComponent,
    RestartIdProofingComponent,
    ConfirmReactivateComponent,
    ReactivateSuccessfulComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule
  ]
})
export class DashboardModule { }
