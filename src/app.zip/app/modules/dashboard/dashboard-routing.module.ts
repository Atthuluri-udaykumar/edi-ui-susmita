import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ResendThankyouComponent } from './resend-thankyou/resend-thankyou.component';
import { ResendTokenComponent } from './resend-token/resend-token.component';
import { UnlockUserAccountComponent } from './unlock-user-account/unlock-user-account.component';
import { IdProofingComponent } from './id-proofing/id-proofing.component';
import { RestartIdProofingComponent } from './restart-id-proofing/restart-id-proofing.component';
import { ConfirmReactivateComponent } from './confirm-reactivate/confirm-reactivate.component';
import { ReactivateSuccessfulComponent } from './reactivate-successful/reactivate-successful.component';

const routes: Routes = [
  {
    path: '', children: [
      { path: '', component: DashboardComponent },
      { path: 'unlock-user-account', component: UnlockUserAccountComponent },
      { path: 'resend-token', component: ResendTokenComponent },
      { path: 'resend-thankyou', component: ResendThankyouComponent },
      { path: 'id-proofing', component : IdProofingComponent },
      { path: 'restart-id-proofing' , component : RestartIdProofingComponent},
      { path: 'confirm-reactivate', component : ConfirmReactivateComponent},
      { path: 'reactivate-successful' , component : ReactivateSuccessfulComponent},
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
