import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-id-proofing',
  templateUrl: './id-proofing.component.html',
  styleUrls: ['./id-proofing.component.css']
})
export class IdProofingComponent implements OnInit {

  constructor(
    private router: Router,
  ) { }

  ngOnInit(): void {
  }

  onContinue(){
    this.router.navigate([`dashboard`]);
 }

}
