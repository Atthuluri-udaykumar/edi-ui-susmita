import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestartIdProofingComponent } from './restart-id-proofing.component';

describe('RestartIdProofingComponent', () => {
  let component: RestartIdProofingComponent;
  let fixture: ComponentFixture<RestartIdProofingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestartIdProofingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestartIdProofingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
