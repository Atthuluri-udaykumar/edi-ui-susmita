import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-restart-id-proofing',
  templateUrl: './restart-id-proofing.component.html',
  styleUrls: ['./restart-id-proofing.component.css']
})
export class RestartIdProofingComponent implements OnInit {

  constructor(
    private router: Router,
  ) { }

  ngOnInit(): void {
  }

  onContinue(){
    this.router.navigate([`dashboard`]);
 }

}

