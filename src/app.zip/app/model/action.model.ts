export interface Action {
  id: number;
  action: string;
}
